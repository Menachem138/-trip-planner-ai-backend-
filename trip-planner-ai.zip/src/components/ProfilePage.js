import React from 'react';

const ProfilePage = () => {
    return (
        <div>
            <h1>Profile Page</h1>
            <p>This is the Profile Page component.</p>
        </div>
    );
};

export default ProfilePage;
